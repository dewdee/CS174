Group members:
Michael Nguyen

Database scheme and table creating is done with the following command: php CreateDb.php
CMD must be pointed to CreateDb.php folder inside src\configs\

Updating cellsheet can be done by pressing enter key

git folder is included, but in case the URL and commits can be found at https://github.com/dewdee/CS174/tree/master/hw4