Group members:
Michael Nguyen

Database scheme and table creating is done with the following command: php CreateDb.php
CMD must be pointed to CreateDb.php folder inside src\configs\